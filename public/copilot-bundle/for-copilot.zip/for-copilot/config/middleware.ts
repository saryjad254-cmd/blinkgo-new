/**
 * Global Middleware
 * ─────────────────
 * Responsibilities:
 *  1. CORS preflight
 *  2. Session refresh (Supabase SSR)
 *  3. Security headers
 *  4. Public path bypass
 *  5. Auth redirect for protected prefixes
 *  6. **CSRF protection** for state-changing API requests
 *  7. **Request body size limit** (DoS protection)
 */
import { NextResponse, type NextRequest } from 'next/server';
import { updateSession } from '@/lib/supabase/middleware';
import { applyCorsHeaders, applySecurityHeaders, handlePreflight } from '@/lib/security-headers';

const PUBLIC_PATHS = [
  '/',
  '/login',
  '/go',
  '/fix-rls',
  '/api/auth/login',
  '/api/auth/logout',
  '/api/auth/register',
  '/api/auth/reset-password',
  '/api/login/submit',
  '/api/stripe/webhook',
  '/api/search',
  '/api/products/bestsellers',
  '/api/products/recent',
  '/api/favorites',
  '/api/health',
];

const MAX_BODY_SIZE_BYTES = 1_000_000; // 1 MB

/**
 * Returns true if the request method can mutate state and therefore
 * requires a CSRF check.
 */
function isStateChanging(method: string): boolean {
  return method === 'POST' || method === 'PUT' || method === 'PATCH' || method === 'DELETE';
}

function isApiPath(path: string): boolean {
  return path.startsWith('/api/');
}

/**
 * CSRF check: reject state-changing API requests from untrusted origins.
 * Allows requests with no Origin (server-to-server) only for explicit
 * allow-listed webhook endpoints.
 */
function csrfCheck(request: NextRequest): NextResponse | null {
  if (!isApiPath(request.nextUrl.pathname)) return null;
  if (!isStateChanging(request.method)) return null;

  const origin = request.headers.get('origin') || request.headers.get('referer') || '';

  // Allow requests with no Origin header from server-to-server endpoints (webhooks)
  if (!origin) {
    // Webhooks (Stripe etc.) are explicitly allow-listed and have their own
    // signature verification.
    const allowNoOrigin = ['/api/stripe/webhook'];
    if (allowNoOrigin.some((p) => request.nextUrl.pathname.startsWith(p))) {
      return null;
    }
    // For other endpoints, allow no-Origin only in dev (helps curl + tests)
    if (process.env.NODE_ENV !== 'production') {
      return null;
    }
    // Reject everything else (browsers always send Origin for state-changing requests)
    return NextResponse.json(
      { ok: false, error: 'CSRF', message: 'Origin required' },
      { status: 403 }
    );
  }

  // Allow localhost in dev
  if (origin.startsWith('http://localhost') || origin.startsWith('http://127.0.0.1')) {
    return null;
  }

  // Allow common tunnel/proxy domains used for demos & previews
  // (loca.lt, ngrok-free.app, cloudflare tunnels, vercel.app, etc.)
  // This is active in BOTH dev and production — these are well-known tunnel
  // providers whose subdomains are random and can't be used for CSRF attacks
  // against other sites. For production deployment, set ALLOWED_ORIGINS env
  // to restrict to your own domains.
  const tunnelHosts = [
    'loca.lt',
    'ngrok.io',
    'ngrok-free.app',
    'ngrok.app',
    'trycloudflare.com',
    'vercel.app',
    'netlify.app',
    'githubpreview.dev',
    'gitpod.io',
  ];
  try {
    const originHost = new URL(origin).host;
    if (tunnelHosts.some((h) => originHost === h || originHost.endsWith('.' + h))) {
      return null;
    }
  } catch {
    // bad URL — fall through to other checks
  }

  // Allow configured app URL
  const appUrl = process.env.NEXT_PUBLIC_APP_URL;
  if (appUrl && origin.startsWith(appUrl)) {
    return null;
  }

  // Allow Vercel preview deployments (only the configured app domain)
  if (appUrl) {
    try {
      const appHost = new URL(appUrl).host;
      const originHost = new URL(origin).host;
      // Same host = allowed
      if (appHost === originHost) return null;
    } catch {
      // bad URL — reject
    }
  }

  return NextResponse.json(
    { ok: false, error: 'CSRF', message: 'Origin not allowed' },
    { status: 403 }
  );
}

export async function middleware(request: NextRequest) {
  // 1) CORS preflight
  if (request.method === 'OPTIONS') {
    return handlePreflight(request);
  }

  // 2) CSRF check (early — before reading the body)
  const csrfError = csrfCheck(request);
  if (csrfError) return csrfError;

  // 3) Body size limit (Content-Length header check; the route also enforces)
  const contentLength = parseInt(request.headers.get('content-length') ?? '0', 10);
  if (contentLength > MAX_BODY_SIZE_BYTES) {
    return NextResponse.json(
      { ok: false, error: 'PAYLOAD_TOO_LARGE', max: MAX_BODY_SIZE_BYTES },
      { status: 413 }
    );
  }

  // 4) Session refresh — SKIP for logout so it doesn't re-issue cookies
  const isLogoutRequest =
    request.method === 'POST' && request.nextUrl.pathname === '/api/auth/logout';
  const { response, user } = isLogoutRequest
    ? { response: NextResponse.next(), user: null }
    : await updateSession(request);
  const path = request.nextUrl.pathname;

  // 5) Security headers + CORS
  applyCorsHeaders(request, response);
  applySecurityHeaders(response);

  // 6) Public path bypass
  if (PUBLIC_PATHS.some((p) => path === p || path.startsWith(`${p}/`))) {
    return response;
  }

  // 7) Protected UI prefixes
  const protectedPrefixes = [
    '/admin',
    '/cart',
    '/orders',
    '/restaurants',
    '/restaurant',
    '/search',
    '/driver',
    '/profile',
  ];
  if (protectedPrefixes.some((p) => path.startsWith(p))) {
    if (!user) {
      const url = request.nextUrl.clone();
      url.pathname = '/login';
      url.searchParams.set('redirect', path);
      return applyCorsHeaders(request, applySecurityHeaders(NextResponse.redirect(url)));
    }
  }

  return response;
}

export const config = {
  matcher: [
    '/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp|zip|bin|pdf|txt|md|json|xml)$).*)',
  ],
};
