import { NextRequest, NextResponse } from 'next/server';
import { authRateLimiters } from '@/lib/rate-limit';
import { isValidEmail, sanitizeText } from '@/lib/validation';
import { ok, fail, withErrorHandling } from '@/lib/api/response';
import { AuthService } from '@/lib/services/auth-service';
import { logger } from '@/lib/logging';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

export async function POST(request: NextRequest): Promise<NextResponse> {
  return withErrorHandling(async () => {
    // 1) Parse + validate input first (so we can rate-limit per-email)
    const body = await request.json().catch(() => ({}));
    const email = sanitizeText(String(body.email ?? '').trim().toLowerCase());
    const password = String(body.password ?? '');
    if (!isValidEmail(email) || !password) {
      return fail(new (await import('@/lib/errors')).ValidationError('Email and password are required'));
    }

    // 2) Rate limit (per-IP AND per-email) — defense against distributed brute force
    const limited = authRateLimiters.login(request, email);
    if (limited) return limited;

    // 3) Delegate to AuthService (single source of truth for auth logic)
    const { user, tokens } = await AuthService.loginFull(email, password);
    logger.info('User login', { userId: user.id, role: user.role });

    // 4) Set cookies server-side
    AuthService.setSessionCookies(tokens);

    // 5) Respond
    return ok({
      user: { id: user.id, email: user.email, role: user.role },
      name: user.name,
      role: user.role,
      redirect: user.redirectPath,
    });
  });
}
