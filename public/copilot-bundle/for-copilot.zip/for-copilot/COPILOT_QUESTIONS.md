# Specific Questions for Copilot — BlinkGo v53

## Q1: Earnings Calculation Correctness
**File**: `business/lib_services_driver_earnings.ts`
**Question**:
- Is the commission split (`DRIVER_DELIVERY_SHARE = 0.8`) applied correctly?
- Are all fees (delivery fee, tip, surge, platform fee) accounted for?
- Any way a driver could receive less than the documented 80%?
- Edge cases: zero tip, negative tip, very large tip, cancelled orders?

## Q2: Login Security
**File**: `api/auth_login.ts`
**Question**:
- Rate limit: per-IP or per-email? How many attempts allowed?
- CSRF: check `Origin` header? Allow-list correct?
- Password comparison: timing-safe (`bcrypt.compare` vs `===`)?
- Any way to enumerate valid emails?
- Generic error messages (no user-existence leak)?

## Q3: Order Creation Race Conditions
**File**: `api/orders_create.ts`
**Question**:
- Is the idempotency key properly enforced for duplicate POSTs?
- Is stock check + order creation atomic? Race condition possible?
- Price validation: server-side check vs trusting client total?
- Restaurant open hours check?
- Delivery radius check (5km server-side)?

## Q4: GPS Privacy & Security
**File**: `api/driver_location.ts`
**Question**:
- Can a customer see ALL drivers or only their assigned one?
- Is `last_location_*` exposed to unauthorized users?
- Throttling: 240/min per driver — too generous? DoS possible?
- Coordinate validation (NaN, out-of-range)?

## Q5: Refund Flow Logic
**File**: `api/orders_refund.ts`
**Question**:
- 7-day window: inclusive or exclusive of delivery date?
- Status check: only `delivered`/`cancelled` — what about `in_transit`?
- Idempotency on refund (double-refund prevention)?
- Stripe refund error handling?
- User authorization: can customer A refund customer B's order?

## Q6: Auth Helper — Redirect Handling
**File**: `business/lib_auth_helper.ts`
**Question**:
- Does `requireApiRole()` properly catch `NEXT_REDIRECT` (500 error)?
- Server-side role check vs trusting `user_metadata`?
- Empty role case handled?
- TypeScript types: is `requireApiRole` properly typed?

## Q7: Middleware CSRF & Logout
**File**: `config/middleware.ts`
**Question**:
- CSRF allow-list: tunnel hosts in BOTH dev and prod (safe?)?
- `updateSession()` skipping on POST `/api/auth/logout`?
- Matcher pattern: covers all API routes? Excludes static files correctly?
- Cookie clearing on logout — all 4 places?

## Q8: Fee Calculation Math
**File**: `business/lib_config_fees.ts`
**Question**:
- `COMMISSION_RATE` correctly applied?
- Delivery fee vs service fee separation?
- Tax calculation (DE: 7% food, 19% other)?
- Refund fee adjustments?

## Q9: Database Schema Issues
**Files**: `schema/01_init.sql`, `schema/03_restaurants.sql`, `schema/05_orders.sql`
**Question**:
- Missing indexes on hot columns (orders.status, orders.driver_id)?
- Foreign key constraints with `ON DELETE` correct?
- `users.role` — using enum or string? Consistent?
- Order status transitions: enforced at DB level or only app?

## Q10: TypeScript Strictness
**File**: `config/tsconfig.json`
**Question**:
- Is `"strict": true` really enforced?
- Any `any` types leaking through?
- Return types on all public functions?
- Generic constraints on shared utilities?

## Q11: SQL Injection Surface
**Files**: All API routes use Supabase client (auto-parameterized), but check:
- Any raw `.rpc()` calls with string interpolation?
- Any `.from()` with dynamic table names?
- Any `.ilike('name', `%${input}%`)` — input sanitized?
- Admin endpoints: more SQL surface, more review needed?

## Q12: Error Information Leakage
**All files**
**Question**:
- Stack traces in production responses?
- Database error messages exposed?
- Stripe / Supabase error details visible?
- Generic messages for users, detailed for logs (structured)?

---

## Out of Scope
- Visual design / UI components
- i18n strings (DE/AR/EN coverage)
- PWA manifest / service worker
- Test scripts (all green)
- Phase reports (already written)

---

## Expected Output
For each question:
1. **Finding**: Yes/No/Partial — with evidence
2. **Severity**: Critical / High / Medium / Low / Informational
3. **File:Line**: Exact location
4. **Fix**: Specific code change with example
5. **Verification**: How to test

Format as a structured report I can paste into a PR.
