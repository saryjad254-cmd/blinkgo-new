# BlinkGo — Context for Copilot Code Review

## Project Overview
**BlinkGo** — Food delivery platform for the German market.
3 languages: **DE (formal/Sie)** + **AR (MSA, no dialect)** + **EN**.
Full RTL support for Arabic.
Production-ready (Phase 5 Certified, Phase 6 Maps complete).

## Tech Stack
- **Next.js 14.2.15** (App Router, Server Components by default)
- **TypeScript** strict mode
- **Supabase** (PostgreSQL + Auth + Realtime + Storage)
- **TailwindCSS** + custom design system (Phase 2)
- **PWA** enabled (manifest + service worker)
- **42 migrations** + 91 API routes + 64 pages + 118 components

## Demo Accounts
| Role | Email | Password |
|---|---|---|
| Customer | `demo@blinkgo.de` | `DemoCustomer!2024` |
| Driver | `driver@blinkgo.de` | `DemoDriver!2024` |
| Restaurant | `restaurant@blinkgo.de` | `DemoRestaurant!2024` |
| Admin | `admin@blinkgo.de` | `DemoAdmin!2024` |

Munich restaurants: `pizza-muc@blinkgo.de`, `sushi-muc@blinkgo.de`, `burger-muc@blinkgo.de` (all use `DemoRestaurant!2024`)

## Architecture
- **Server Components** by default; client only when needed (interactivity)
- **Auth**: Cookie-based Supabase (no localStorage tokens)
- **Defense in depth**: CSP + CSRF allow-list (tunnel hosts) + rate limit + input validation
- **Single source of truth** for earnings: `lib/services/driver-earnings.ts::computeEarnings()`
- **GPS only active** when driver is online (privacy)
- **Defensive code**: graceful fallbacks for missing tables (`PGRST205` catch pattern)
- **Idempotency**: 24h TTL, 10K in-memory cache for state-changing ops
- **AbortController**: 25s timeout for all critical API calls

## Important Conventions
- **German**: formal "Sie/Ihr" — never "du/dein"
- **Arabic**: MSA only — no Iraqi/Egyptian/Levantine dialect
- **Currency**: use `formatEUR()` from `lib/format`
- **Touch targets**: ≥ 44px + `touch-manipulation` class
- **Distance**: Haversine formula in `lib/maps/distance.ts`
- **Role from public.users** table (NOT `user_metadata`) — security
- **No env var names** in user-facing errors — generic messages
- **Inline validation** on blur (not onSubmit)
- **WCAG 2.1 AA**: `aria-invalid`, `aria-describedby`, `role="alert"`
- **`autoComplete="username"`** for email (NOT "email") for password managers
- **autoComplete="current-password"** for password
- **Migrations**: must be applied OR code must gracefully degrade

## Critical Files in This Bundle
1. **Config**: `package.json`, `middleware.ts`, `tsconfig.json`
2. **Schema**: `01-init-schema.sql`, `03-restaurants.sql`, `05-orders.sql`
3. **Business**: `lib/config/fees.ts`, `lib/services/driver-earnings.ts`, `lib/auth-helper.ts`
4. **API**: `auth/login/route.ts`, `orders/route.ts`, `orders/[id]/refund/route.ts`, `driver/location/route.ts`

## Test Status (200/200+ passing)
- Customer journey: 29/29 ✅
- Driver stress: 23/23 ✅
- Restaurant workflow: 18/18 ✅
- Admin workflow: 24/24 ✅
- Edge cases: 20/20 ✅
- Ops acceptance: 30/30 ✅
- Maps: 15/15 ✅
- Driver experience: 14/14 ✅
- Stress test: 100+ RPS, 96.7% success ✅

## What to Focus On
- **Security**: SQL injection, XSS, CSRF bypass, IDOR, privilege escalation
- **Performance**: N+1 queries, missing indexes, memory leaks
- **Type safety**: `any` usage, missing return types
- **Business logic**: earnings calculation correctness, fee math
- **Race conditions**: order creation, status transitions
- **Auth**: cookie security, session validation, role enforcement
- **Input validation**: at every API entry point
- **Error handling**: no info leakage, proper status codes

## What NOT to Focus On
- Visual design (already passed Phase 2 audit)
- i18n completeness (all 3 languages done)
- Test coverage (all green)
- Documentation (6 phase reports written)
- PWA / manifest / icons (working)

## Specific Concerns to Check
1. **Driver earnings**: Is `DRIVER_DELIVERY_SHARE = 0.8` applied correctly? All fees included?
2. **Order creation**: Idempotency key properly enforced? Stock check race-safe?
3. **Login**: Rate limit per-IP vs per-email? CSRF check on POST?
4. **Location updates**: Privacy — only assigned customer can see? Throttling correct?
5. **Refund flow**: 7-day window logic? Status check (only delivered/cancelled)?
6. **Auth helper**: `requireApiRole()` vs `requireRole()` — is NEXT_REDIRECT properly caught?
7. **Middleware**: Logout cookie clearing? CSRF origin allow-list exhaustive?
8. **Fee calculation**: Commission + delivery + tip math correct?

## Known Defensive Patterns (OK, don't flag)
- `try { ... } catch (PGRST205) { return [] }` — table missing, graceful empty
- Empty result fallbacks for missing columns
- `Math.min/max` for tip clamping
- UUID regex accepts all-numeric seed data

## Project Files
- **Bundle ZIP**: `/workspace/blinkgo-final.zip` (1.6 MB, 705 files)
- **Workspace**: `/workspace/blinkgo-flat/`
- **Live**: `https://sad-adults-start.loca.lt`
- **Reports**: `AUDIT_REPORT.md`, `PHASE_2_REPORT.md` → `PHASE_6_REPORT.md`

---

*Generated for Microsoft Copilot code review — Phase 6 (v53)*
