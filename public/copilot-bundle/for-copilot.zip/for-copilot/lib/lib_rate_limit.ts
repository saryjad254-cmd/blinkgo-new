// Production-grade rate limiter for Next.js API Routes
// Uses sliding window algorithm with in-memory store (process-level)
// Edge-compatible: works in both Node.js and Edge runtimes

import { NextResponse } from 'next/server';

export interface RateLimitConfig {
  /** Max requests allowed in the window */
  limit: number;
  /** Time window in seconds */
  windowSec: number;
  /** Identifier for the bucket (e.g. 'login', 'register') */
  name: string;
  /** Custom key generator - default uses IP */
  keyFn?: (req: Request) => string | null;
}

interface Bucket {
  count: number;
  resetAt: number; // ms epoch
}

// In-memory store. Resets on process restart, which is acceptable
// for an MVP and provides a hard reset on deploys.
// For multi-instance prod, swap with Upstash Ratelimit + Redis.
const store = new Map<string, Bucket>();

// Cleanup every 5 min to prevent memory leaks
if (typeof setInterval !== 'undefined') {
  const cleanupInterval = setInterval(
    () => {
      const now = Date.now();
      for (const [k, v] of store.entries()) {
        if (v.resetAt < now) store.delete(k);
      }
    },
    5 * 60 * 1000,
  );
  // Don't block process exit
  if (typeof (cleanupInterval as any).unref === 'function') {
    (cleanupInterval as any).unref();
  }
}

/** Extract client IP from various headers (works in dev and behind proxies) */
export function getClientIp(req: Request): string {
  // Try common headers in order of preference
  const xff = req.headers.get('x-forwarded-for');
  if (xff) {
    // First IP in the list is the original client
    return xff.split(',')[0]!.trim();
  }
  const realIp = req.headers.get('x-real-ip');
  if (realIp) return realIp.trim();
  const cfIp = req.headers.get('cf-connecting-ip');
  if (cfIp) return cfIp.trim();
  // Fallback (rare; dev only)
  return 'unknown';
}

/**
 * Check rate limit and return either null (allowed) or a 429 response.
 * Usage:
 *   const limited = rateLimit({ limit: 5, windowSec: 900, name: 'login' }, req);
 *   if (limited) return limited;
 */
export function rateLimit(config: RateLimitConfig, req: Request): NextResponse | null {
  const { limit, windowSec, name } = config;
  const keyFn = config.keyFn || (() => getClientIp(req));
  const id = keyFn(req);
  if (!id) return null; // No identifier, skip rate limiting (can't apply)

  const key = `${name}:${id}`;
  const now = Date.now();
  const bucket = store.get(key);

  if (!bucket || bucket.resetAt < now) {
    // New bucket
    store.set(key, { count: 1, resetAt: now + windowSec * 1000 });
    return null;
  }

  bucket.count++;
  if (bucket.count > limit) {
    // Rate limited - return 429 with informative headers
    const retryAfterSec = Math.ceil((bucket.resetAt - now) / 1000);
    return NextResponse.json(
      {
        ok: false,
        error: 'RATE_LIMITED',
        message: 'Too many requests. Please try again later.',
        retryAfter: retryAfterSec,
      },
      {
        status: 429,
        headers: {
          'Retry-After': String(retryAfterSec),
          'X-RateLimit-Limit': String(limit),
          'X-RateLimit-Remaining': '0',
          'X-RateLimit-Reset': String(Math.ceil(bucket.resetAt / 1000)),
          'Content-Type': 'application/json',
        },
      },
    );
  }

  return null;
}

/** Convenience wrapper for common auth endpoints */
export const authRateLimiters = {
  login: (req: Request, email?: string) =>
    rateLimit({ limit: 20, windowSec: 15 * 60, name: email ? `login:ip:${getClientIp(req)}:email:${email.toLowerCase()}` : 'login' }, req),
  register: (req: Request) =>
    rateLimit({ limit: 10, windowSec: 15 * 60, name: 'register' }, req),
  passwordReset: (req: Request) =>
    rateLimit({ limit: 5, windowSec: 15 * 60, name: 'password-reset' }, req),
  otpVerify: (req: Request, email?: string) =>
    rateLimit({ limit: 10, windowSec: 15 * 60, name: email ? `otp-verify:${email.toLowerCase()}` : 'otp-verify' }, req),
  otpResend: (req: Request, email?: string) =>
    rateLimit({ limit: 3, windowSec: 5 * 60, name: email ? `otp-resend:${email.toLowerCase()}` : 'otp-resend' }, req),
  // Magic link: stricter than OTP, prevents email bombing
  magicLink: (req: Request, email?: string) =>
    rateLimit({ limit: 5, windowSec: 60 * 60, name: email ? `magic-link:${email.toLowerCase()}` : `magic-link:${getClientIp(req)}` }, req),
  // For non-auth endpoints that need protection
  contactForm: (req: Request) =>
    rateLimit({ limit: 3, windowSec: 60, name: 'contact' }, req),
  // Per-email rate limiter (for OTP testing fallback)
  perEmail: (email: string) => (req: Request) =>
    rateLimit(
      {
        limit: 10,
        windowSec: 15 * 60,
        name: `email:${email.toLowerCase()}`,
      },
      req,
    ),
};

/** Get current stats for a key (for testing/monitoring) */
export function getRateLimitStats(name: string, id: string): { count: number; resetAt: number } | null {
  const key = `${name}:${id}`;
  const b = store.get(key);
  if (!b) return null;
  return { count: b.count, resetAt: b.resetAt };
}

/** Clear all rate limit buckets (admin/test use) */
export function clearRateLimits(): void {
  store.clear();
}
